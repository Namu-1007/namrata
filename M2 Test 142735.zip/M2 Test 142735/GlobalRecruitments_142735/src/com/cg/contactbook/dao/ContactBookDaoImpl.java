package com.cg.contactbook.dao;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import org.apache.log4j.Level;
import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

import com.cg.contactbook.bean.EnquiryBean;
import com.cg.contactbook.exception.ContactBookException;
import com.cg.contactbook.util.DBUtil;

public class ContactBookDaoImpl implements ContactBookDao
{
	Connection con=null;
	Statement st=null;
	PreparedStatement pst=null;
	ResultSet rs=null;
	Logger enqryLogger=null;
	
	public ContactBookDaoImpl()
	{
		PropertyConfigurator.configure("resources/log4j.properties");
		enqryLogger=Logger.getLogger("ContactBookDaoImpl.class");
	}

	@Override
	public int addEnquiry(EnquiryBean enqry) throws ContactBookException 
	{
		String insertQry="INSERT INTO enquiry(enqryId,firstName,lastName,contactNo,domain,city)" 
						+"VALUES(?,?,?,?,?,?)";
		int dataAdded=0;
		try
		{
			con=DBUtil.getCon();
			pst=con.prepareStatement(insertQry);
			pst.setInt(1, generateEnqryId());
			pst.setString(2, enqry.getfName());
			pst.setString(3, enqry.getlName());
			pst.setString(4, enqry.getContactNo());
			pst.setString(5, enqry.getpLocation());
			pst.setString(6, enqry.getpDomain());
			dataAdded=pst.executeUpdate();
		    enqryLogger.log(Level.INFO,"Data Inserted: "+enqry);
		} 
		catch (Exception e)
		{
			throw new ContactBookException (e.getMessage());
		} 
		finally
		{
			try
			{
				pst.close();
				con.close();
			} 
			catch (SQLException e)
			{
				enqryLogger.error("This is Exception:"+e.getMessage());
				throw new ContactBookException(e.getMessage());
			}
		}		
		return dataAdded;
	}

	@Override
	public EnquiryBean getEnquiryDetails(int enqryId)throws ContactBookException 
	{
		String selQry="SELECT * FROM enquiry WHERE enqryId="+enqryId;
		EnquiryBean eb=null;
		try 
		{
			con=DBUtil.getCon();
			st=con.createStatement();
			rs=st.executeQuery(selQry);
			while(rs.next())
			{
				System.out.println(rs.getInt(1)+"\t"+
						rs.getString(2)+"\t"+
						rs.getString(3)+"\t"+
						rs.getString(4)+"\t"+
						rs.getString(5)+"\t"+
						rs.getString(6));
			}
			 enqryLogger.log(Level.ERROR,"Some error has occurred: "+enqryId);
		} 
		catch (Exception e) 
		{
			throw new ContactBookException (e.getMessage());
		} 	
		finally
		{
			try
			{
				rs.close();
				st.close();
				con.close();
			} 
			catch (SQLException e)
			{
				enqryLogger.error("This is Exception:"+e.getMessage());
				throw new ContactBookException(e.getMessage());
			}
		}	
		return eb;
	}

	@Override
	public int generateEnqryId() throws ContactBookException 
	{
		String qry="SELECT enquiries.NEXTVAL FROM dual";
		int generatedVal;
		int eqid;
		try 
		{
			con=DBUtil.getCon();
			st=con.createStatement();
			rs=st.executeQuery(qry);
			rs.next();
			 generatedVal=rs.getInt(1);
			 eqid=generatedVal;
			 enqryLogger.info("Enquiry id generated");
			
		} 
		catch (Exception e) 
		{
			throw new ContactBookException (e.getMessage());
		} 
		finally
		{
			try
			{
				rs.close();
				st.close();
				con.close();
			} 
			catch (SQLException e)
			{
				enqryLogger.error("This is Exception:"+e.getMessage());
				throw new ContactBookException(e.getMessage());
			}
		}		
		return eqid;
	}

}
