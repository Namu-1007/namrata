package com.cg.contactbook.dao;

import java.util.ArrayList;

import com.cg.contactbook.bean.EnquiryBean;
import com.cg.contactbook.exception.ContactBookException;



public interface ContactBookDao
{
	public int addEnquiry(EnquiryBean enqry) throws ContactBookException;
	public EnquiryBean getEnquiryDetails(int enqryId)throws ContactBookException;
	public int generateEnqryId() throws ContactBookException;
}
