package com.cg.contactbook.ui;

import java.util.Scanner;

import com.cg.contactbook.bean.EnquiryBean;
import com.cg.contactbook.exception.ContactBookException;
import com.cg.contactbook.service.ContactBookService;
import com.cg.contactbook.service.ContactBookServiceImpl;

public class Client
{
	static Scanner sc=null;
	static ContactBookService conSer=null;
		public static void main(String[] args)
	{
		conSer=new ContactBookServiceImpl();
		sc=new Scanner(System.in);
		int choice=0;
		while(true)
		{
			System.out.println("************Global Recruitments*************");
			System.out.println("Choose an operation");
			System.out.println("1.Enter Enquiry Details\n2.View Enquiry Details on Id\n0.Exit");
			System.out.println("******************************");
			System.out.println("Please enter a choice: ");
			choice=sc.nextInt();
			switch(choice)
			{
				case 1:addEnquiry();
					break;
				case 2:viewEnquiry(); 
					break;
				default: System.out.println("Thank you for selecting us!!");
			}
		}
	}
	/*******************main ends here******************/
		public static void addEnquiry()
		{
			System.out.println("Enter First Name: ");
			String fnm=sc.next();
			try 
			{
				if(conSer.validateFirstName(fnm))
				{
					System.out.println("Enter Last Name: ");
					String lnm=sc.next();
					if(conSer.validateLastName(lnm))
					{
						System.out.println("Enter Contact Number: ");
						String cNo=sc.next();
						if(conSer.validateContactNo(cNo))
						{
							System.out.println("Enter Preferred Domain: ");
							String pDom=sc.next();
							if(conSer.validatePDomain(pDom))
							{
								System.out.println("Enter Preferred Location: ");
								String pLoc=sc.next();
								if(conSer.validatePDomain(pLoc))
								{
									EnquiryBean eb=new EnquiryBean();
									eb.setfName(fnm);
									eb.setlName(lnm);
									eb.setContactNo(cNo);
									eb.setpDomain(pDom);
									eb.setpLocation(pLoc);
									int dataAdded=conSer.addEnquiry(eb);
									if(dataAdded==1)
									{
										System.out.println("Thank you "+fnm+" " +lnm +" your Unique Id is "+conSer.generateEnqryId()+" we will contact you shortly.");
									}
									else
									{
										System.out.println("May be some exception has occurred while addition");
									}
									
								}
							}
						}
					}
				}
			} 
			catch (ContactBookException e)
			{
				System.out.println(e.getMessage());
			}
		}
	/**************************************************/	
		public static void viewEnquiry()
		{
			System.out.println("Enter the Enquiry No.: ");
			int eqrNo=sc.nextInt();
			
			System.out.println("Id\tFirst Name\tLast name\tContact no.\tPreferred Domain\tPreferred Location");
			
			EnquiryBean eb=new EnquiryBean();
			
			try 
			{
				conSer.getEnquiryDetails(eqrNo);
				System.out.println(eb);
			}
			catch (ContactBookException e)
			{
				System.out.println("Some exception while fetching data");
				
			}
		}
}
