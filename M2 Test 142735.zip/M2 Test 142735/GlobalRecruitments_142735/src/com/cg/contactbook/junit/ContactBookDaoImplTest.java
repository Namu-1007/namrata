package com.cg.contactbook.junit;
import org.junit.Assert;
import org.junit.BeforeClass;
import org.junit.Test;

import com.cg.contactbook.bean.EnquiryBean;
import com.cg.contactbook.dao.ContactBookDao;
import com.cg.contactbook.dao.ContactBookDaoImpl;
import com.cg.contactbook.exception.ContactBookException;


public class ContactBookDaoImplTest 
{
	static ContactBookDao conDao;
	static EnquiryBean eb=null;
	@BeforeClass
	public static void beforeClass() throws ContactBookException
	{
		conDao=new ContactBookDaoImpl();
	
		
	}
}
