package com.cg.contactbook.exception;

public class ContactBookException extends Exception
{
	public ContactBookException(String msg)
	{
		super(msg);
		
	}
}
