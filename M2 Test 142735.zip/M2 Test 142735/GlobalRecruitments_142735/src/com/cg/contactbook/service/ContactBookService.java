package com.cg.contactbook.service;

import com.cg.contactbook.bean.EnquiryBean;
import com.cg.contactbook.exception.ContactBookException;

public interface ContactBookService 
{
	public int addEnquiry(EnquiryBean enqry) throws ContactBookException;
	public EnquiryBean getEnquiryDetails(int enqryId)throws ContactBookException;
	public int generateEnqryId() throws ContactBookException;
	public boolean validateFirstName(String fName) throws ContactBookException;
	public boolean validateLastName(String lName) throws ContactBookException;
	public boolean validateContactNo(String contactNo) throws ContactBookException;
	public boolean validatePDomain(String pDomain) throws ContactBookException;
	public boolean validatePLocation(String pLocation) throws ContactBookException;
	
}
