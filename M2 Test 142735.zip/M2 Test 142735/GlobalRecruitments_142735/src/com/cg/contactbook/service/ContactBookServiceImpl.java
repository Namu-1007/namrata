package com.cg.contactbook.service;

import java.util.regex.Pattern;

import com.cg.contactbook.bean.EnquiryBean;
import com.cg.contactbook.dao.ContactBookDao;
import com.cg.contactbook.dao.ContactBookDaoImpl;
import com.cg.contactbook.exception.ContactBookException;

public class ContactBookServiceImpl implements ContactBookService
{
	ContactBookDao contactbookDao=null;
	public ContactBookServiceImpl()
	{
		contactbookDao=new ContactBookDaoImpl();
	}

	@Override
	public int addEnquiry(EnquiryBean enqry) throws ContactBookException 
	{
		return contactbookDao.addEnquiry(enqry);
	}

	@Override
	public EnquiryBean getEnquiryDetails(int enqryId) throws ContactBookException 
	{
		return contactbookDao.getEnquiryDetails(enqryId);
	}

	@Override
	public int generateEnqryId() throws ContactBookException
	{
		return contactbookDao.generateEnqryId();
	}

	@Override
	public boolean validateFirstName(String fName) throws ContactBookException 
	{
		String fnamePattern="[A-Z][a-z]+";
		if(Pattern.matches(fnamePattern, fName))
		{
			return true;
		}
		else
		{		
			throw new ContactBookException("Only Chars allowed in first name and should start with capital. eg.Namrata");
		}

	}
	@Override
	public boolean validateLastName(String lName) throws ContactBookException {
		String lnamePattern="[A-Z][a-z]+";
		if(Pattern.matches(lnamePattern, lName))
		{
			return true;
		}
		else
		{		
			throw new ContactBookException("Only Chars allowed in last name and should start with capital. eg.Mehta");
		}

	}

	@Override
	public boolean validateContactNo(String contactNo)throws ContactBookException 
	{
		String numPattern="[7-9][0-9]{9}";
		if(Pattern.matches(numPattern, contactNo))
		{
			return true;
		}
		else
		{		
			throw new ContactBookException("Enter a valid contact number. eg:9563245217");
		}
	}

	@Override
	public boolean validatePDomain(String pDomain) throws ContactBookException
	{
		String pdomainPattern="[A-Za-z]+";
		if(Pattern.matches(pdomainPattern, pDomain))
		{
			return true;
		}
		else
		{		
			throw new ContactBookException("Enter a valid domain. eg:Java");
		}
	}

	@Override
	public boolean validatePLocation(String pLocation)throws ContactBookException {
		String plocationPattern="[A-Za-z]+";
		if(Pattern.matches(plocationPattern, pLocation))
		{
			return true;
		}
		else
		{		
			throw new ContactBookException("Enter a valid Location. eg:Pune");
		}
	}

}
