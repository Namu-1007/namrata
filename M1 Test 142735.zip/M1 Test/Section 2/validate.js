function validate(){
    
    
    var ticket =document.frm1.ticket.value;
    
    var price;
      
    var Name=document.getElementById("name").value;
    
    var number=document.getElementById("no").value;
    
	if (ticket == 1)
    {
        alert("Customer Name: "+Name + "\n Mobile No.: " + number + "\n No.of Tickets: " + ticket  )  
        ticket.focus();
        return true;
    }
    else if (ticket == 2)
    {
         alert("Customer Name: "+Name + "\n Mobile No.: " + number + "\n No.of Tickets: " + ticket  )  
        ticket.focus();
        return true;
    }
    else if (ticket == 3)
    {
         alert("Customer Name: "+Name + "\n Mobile No.: " + number + "\n No.of Tickets: " + ticket  )  
        ticket.focus();
        return true;
    }
    else if (ticket == 3)
    {
         alert("Customer Name: "+Name + "\n Mobile No.: " + number + "\n No.of Tickets: " + ticket  )  
        ticket.focus();
        return true;
    }
    else if (ticket == 4)
    {
         alert("Customer Name: "+Name + "\n Mobile No.: " + number + "\n No.of Tickets: " + ticket  )  
        ticket.focus();
        return true;
    }
    else if (ticket == 5)
    {
         alert("Customer Name: "+Name + "\n Mobile No.: " + number + "\n No.of Tickets: " + ticket  )  
        ticket.focus();
        return true;
    }
    else if (ticket == 6)
    {
         alert("Customer Name: "+Name + "\n Mobile No.: " + number + "\n No.of Tickets: " + ticket  )  
        ticket.focus();
        return true;
    }
    
    else if (ticket == 7)
    {
         alert("Customer Name: "+Name + "\n Mobile No.: " + number + "\n No.of Tickets: " + ticket  )  
        ticket.focus();
        return true;
    }
    else if (ticket == 8)
    {
         alert("Customer Name: "+Name + "\n Mobile No.: " + number + "\n No.of Tickets: " + ticket  )  
        ticket.focus();
        return true;
    }
    else if (ticket == 9)
    {
         alert("Customer Name: "+Name + "\n Mobile No.: " + number + "\n No.of Tickets: " + ticket  )  
        ticket.focus();
        return true;
    }
    else if (ticket == 10)
    {
         alert("Customer Name: "+Name + "\n Mobile No.: " + number + "\n No.of Tickets: " + ticket  )  
        ticket.focus();
        return true;
    }
    
      return true;
      
}
    

    
        
    
  
    
    

    
    

