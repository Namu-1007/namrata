package com.cg.elm.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.cg.elm.dto.EmpLeaveDetails;
import com.cg.elm.dto.EmployeeDetails;
import com.cg.elm.service.IEmpLeaveService;


@Controller
public class EmpController 
{
	@Autowired
	IEmpLeaveService empleaveservice;

	@RequestMapping(value="home",method=RequestMethod.GET)
	public String getHome()
	{
		return "Home";

	}


	@RequestMapping(value="search",method=RequestMethod.GET)
	public ModelAndView viewEmployee(@ModelAttribute("empl") EmpLeaveDetails leavedetails,@RequestParam("eid") int eid)
	{
		if(empleaveservice.validateEmpId(eid) == true )
		{
			if(empleaveservice.validateEmpIds(eid) == true)
			{
				List<EmpLeaveDetails> ed = empleaveservice.getLeaveDetails(eid);
				return new ModelAndView("ViewLeaveDetails","ed",ed);
			}
			else
			{
				return new ModelAndView("ViewHistory");
			}
		}
		else
		{
			return new ModelAndView("myError");
		}
		//		List<EmpLeaveDetails> ed = empleaveservice.getLeaveDetails(eid);
		//		ModelAndView mv = new ModelAndView();
		//	
		//		if (ed != null) {
		//			mv.setViewName("ViewLeaveDetails");
		//			mv.addObject("ed", ed);
		//		} else {
		//			String msg = "This Employee ID Does not exist...";
		//			mv.setViewName("myError");
		//			mv.addObject("msg", msg);
		//		}
		//		return mv;
	}
}
