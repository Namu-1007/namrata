package com.cg.elm.exception;

public class LeaveException extends Exception
{
	public LeaveException()
	{
		
	}
	public LeaveException(String msg)
	{
		super(msg);
	}
}
