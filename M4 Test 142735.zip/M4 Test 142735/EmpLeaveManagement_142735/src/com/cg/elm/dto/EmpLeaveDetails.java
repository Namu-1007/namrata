package com.cg.elm.dto;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="employee_leave_details")
public class EmpLeaveDetails 
{
	@Id
	@Column(name="leave_id")
	private Integer leaveId;
	@Column(name="empid")
	private Integer empId;
	@Column(name="start_date")
	private String startDate;
	@Column(name="end_date")
	private String endDate;
	@Column(name="description")
	private String description;
	@Column(name="leaves_applied")
	private Integer leavesApplied;
	public Integer getLeaveId() {
		return leaveId;
	}
	public void setLeaveId(Integer leaveId) {
		this.leaveId = leaveId;
	}
	public Integer getEmpId() {
		return empId;
	}
	public void setEmpId(Integer empId) {
		this.empId = empId;
	}
	public String getStartDate() {
		return startDate;
	}
	public void setStartDate(String startDate) {
		this.startDate = startDate;
	}
	public String getEndDate() {
		return endDate;
	}
	public void setEndDate(String endDate) {
		this.endDate = endDate;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public Integer getLeavesApplied() {
		return leavesApplied;
	}
	public void setLeavesApplied(Integer leavesApplied) {
		this.leavesApplied = leavesApplied;
	}
	
	
}
