package com.cg.elm.service;

import java.util.List;

import com.cg.elm.dto.EmpLeaveDetails;


public interface IEmpLeaveService 
{
	public List<EmpLeaveDetails> getLeaveDetails(int empid);
	public List<Integer> getEIds();
	public List<Integer> getEmpIds();
	public boolean validateEmpId(int eid);
	public boolean validateEmpIds(int eids);
}
