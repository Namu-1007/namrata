package com.cg.elm.service;

import java.util.Iterator;
import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.elm.dao.IEmpLeaveDao;
import com.cg.elm.dto.EmpLeaveDetails;

@Service("empleaveservice")
@Transactional
public class EmpLeaveServiceImpl implements IEmpLeaveService
{
	@Autowired
	IEmpLeaveDao empleavedao;

	@Override
	public List<EmpLeaveDetails> getLeaveDetails(int empid)
	{
		return empleavedao.getLeaveDetails(empid);
	}

	@Override
	public List<Integer> getEIds()
	{
		return empleavedao.getEIds();
	}

	@Override
	public List<Integer> getEmpIds() 
	{
		return empleavedao.getEmpIds();
	}

	@Override
	public boolean validateEmpId(int eid)
	{
		int cnt=0;
		Iterator iterator = empleavedao.getEIds().iterator();
		while(iterator.hasNext())
		{
			int id = (int)iterator.next();
			if(eid==id)
			{
				cnt=1;
				break;
			}
		}
		if(cnt==1)
		{
			return true;
		}
		else
		{
			return false;
		}
	}

	@Override
	public boolean validateEmpIds(int eids)
	{
		int cnt=0;
		Iterator iterator = empleavedao.getEmpIds().iterator();
		while(iterator.hasNext())
		{
			int id = (int)iterator.next();
			if(eids==id)
			{
				cnt=1;
				break;
			}
		}
		if(cnt==1)
		{
			return true;
		}
		else
		{
			return false;
		}
	}

	

	
}
