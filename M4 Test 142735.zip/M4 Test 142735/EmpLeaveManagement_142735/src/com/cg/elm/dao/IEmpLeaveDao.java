package com.cg.elm.dao;



import java.util.List;

import com.cg.elm.dto.EmpLeaveDetails;
import com.cg.elm.dto.EmployeeDetails;

public interface IEmpLeaveDao 
{
	public List<EmpLeaveDetails> getLeaveDetails(int empid);
	public List<Integer> getEIds();
	public List<Integer> getEmpIds();
	
}
