package com.cg.elm.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;

import com.cg.elm.dto.EmpLeaveDetails;
import com.cg.elm.dto.EmployeeDetails;

@Repository("empleavedao")
public class EmpLeaveDaoImpl implements IEmpLeaveDao
{
	@PersistenceContext
	EntityManager entitymanager;

	@Override
	public List<EmpLeaveDetails> getLeaveDetails(int empid)
	{
		Query queryone = entitymanager.createQuery("SELECT e FROM EmpLeaveDetails e WHERE empId=:eid");
		queryone.setParameter("eid", empid);
		return queryone.getResultList();
	}

	@Override
	public List<Integer> getEIds() 
	{
		Query querytwo = entitymanager.createQuery("SELECT empId FROM EmployeeDetails");
		return querytwo.getResultList();
	}

	@Override
	public List<Integer> getEmpIds()
	{
		Query querythree = entitymanager.createQuery("SELECT empId FROM EmpLeaveDetails");
		return querythree.getResultList();
	}

	
	

}
