package com.cg.service;

import java.util.ArrayList;

import com.cg.bean.Hotels;
import com.cg.bean.User;
import com.cg.dao.UserDao;
import com.cg.dao.UserDaoImpl;
import com.cg.exception.HotelException;

public class UserServiceImpl implements UserService
{
	UserDao userdao=null;
	public UserServiceImpl()
	{
		userdao=new UserDaoImpl();
	}

	@Override
	public ArrayList<Hotels> searchAllHotels(String city) throws HotelException 
	{
		return userdao.searchAllHotels(city);
	}

	@Override
	public boolean login(User user) throws HotelException
	{
		return userdao.login(user);
	}

	@Override
	public int registerUser(User user) throws HotelException
	{
		return userdao.registerUser(user);
	}

}
