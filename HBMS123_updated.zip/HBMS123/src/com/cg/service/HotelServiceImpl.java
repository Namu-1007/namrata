package com.cg.service;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.regex.Pattern;

import com.cg.bean.BookingDetails;
import com.cg.bean.Hotels;
import com.cg.bean.RoomDetails;
import com.cg.dao.HotelDao;
import com.cg.dao.HotelDaoImpl;
import com.cg.exception.HotelException;


public class HotelServiceImpl implements HotelService
{
	HotelDao hdao=null;
	public HotelServiceImpl()
	{
		hdao=new HotelDaoImpl();
	}
	@Override
	public int addHotels(Hotels htl) throws HotelException 
	{
		return hdao.addHotels(htl);
	}
	@Override
	public String updateHtl(Hotels hotel) throws HotelException 
	{
		return hdao.updateHtl(hotel);
	}
	@Override
	public boolean validateAdmName(String cName) throws HotelException 
	{
		String namePattern="admin";
		if(Pattern.matches(namePattern,cName))
		{
			return true;
		}
		else
		{
			throw new HotelException("Invalid Name");
		}
	}
	@Override
	public boolean validateAdmPass(String adPass) throws HotelException
	{
		String namePattern="admin";
		if(Pattern.matches(namePattern,adPass))
		{
			return true;
		}
		else
		{
			throw new HotelException("Invalid Password");
		}
	}
	@Override
	public String generateHotelId() throws HotelException 
	{
		return hdao.generateHotelId();
	}
	@Override
	public int deleteHtl(int htlId) throws HotelException
	{	
		return hdao.deleteHtl(htlId);
	}
	@Override
	public int addRooms(RoomDetails room) throws HotelException 
	{
		return hdao.addRooms(room);
	}
	@Override
	public String updateRoom(RoomDetails room) throws HotelException 
	{
		return hdao.updateRoom(room);
	}
	@Override
	public String deleteRoom(String roomid, String hid) throws HotelException 
	{
		return hdao.deleteRoom(roomid, hid);
	}
	@Override
	public ArrayList<Hotels> getAllHotels() throws HotelException 
	{
		return hdao.getAllHotels();
	}
	@Override
	public ArrayList<BookingDetails> viewBookingsSpecificHotel(LocalDate bookdate) throws HotelException 
	{
		return hdao.viewBookingsSpecificHotel(bookdate);
	}
	

}
