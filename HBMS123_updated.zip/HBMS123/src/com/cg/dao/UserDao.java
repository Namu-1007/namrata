package com.cg.dao;

import java.util.ArrayList;

import com.cg.bean.Hotels;
import com.cg.bean.User;
import com.cg.exception.HotelException;

public interface UserDao 
{
	public boolean login(User user) throws HotelException;
	
	public int registerUser(User user) throws HotelException;
	
	public ArrayList<Hotels> searchAllHotels(String city) throws HotelException;
}
