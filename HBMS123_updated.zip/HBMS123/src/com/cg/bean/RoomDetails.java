package com.cg.bean;

public class RoomDetails {
	private String hotelId;
	private String id;
	private String number;
	private String type;
	private double perNightRate;
	private int availability;

	public RoomDetails() {
		super();
	}

	public RoomDetails(String hotelId, String id, String number, String type, double perNightRate, int availability) {
		super();
		this.hotelId = hotelId;
		this.id = id;
		this.number = number;
		this.type = type;
		this.perNightRate = perNightRate;
		this.availability = availability;
	}

	public String getHotelId() {
		return hotelId;
	}

	public void setHotelId(String hotelId) {
		this.hotelId = hotelId;
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getNumber() {
		return number;
	}

	public void setNumber(String number) {
		this.number = number;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public double getPerNightRate() {
		return perNightRate;
	}

	public void setPerNightRate(double perNightRate) {
		this.perNightRate = perNightRate;
	}

	public int getAvailability() {
		return availability;
	}

	public void setAvailability(int string) {
		this.availability = string;
	}

	@Override
	public String toString() {
		return "RoomDetails [id=" + id + ", number=" + number + ", type=" + type + ", perNightRate=" + perNightRate
				+ ", availability=" + availability + "]";
	}

}
