package com.cg.gca.service;

import java.util.List;

import com.cg.gca.dto.OnlineGames;
import com.cg.gca.dto.Users;
import com.cg.gca.exception.GameException;

public interface GameCityService 
{
	int addUserDetails(Users u) throws GameException;
	List<OnlineGames> getAllGames() throws GameException;
}
