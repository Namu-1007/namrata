package com.cg.gca.service;

import java.util.List;

import com.cg.gca.dao.GameCityDao;
import com.cg.gca.dao.GameCityDaoImpl;
import com.cg.gca.dto.OnlineGames;
import com.cg.gca.dto.Users;
import com.cg.gca.exception.GameException;

public class GameCityServiceImpl implements GameCityService 
{
GameCityDao gDao=new GameCityDaoImpl();
	@Override
	public int addUserDetails(Users u) throws GameException 
	{
		return gDao.addUserDetails(u);
	}
	@Override
	public List<OnlineGames> getAllGames() throws GameException 
	{
		return gDao.getAllGames();
	}

}
