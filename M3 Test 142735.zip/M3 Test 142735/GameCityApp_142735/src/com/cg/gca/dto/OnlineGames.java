package com.cg.gca.dto;

public class OnlineGames 
{
	private String gName;
	private int gAmt;
	public String getgName() {
		return gName;
	}
	public void setgName(String gName) {
		this.gName = gName;
	}
	public int getgAmt() {
		return gAmt;
	}
	public void setgAmt(int gAmt) {
		this.gAmt = gAmt;
	}
	public OnlineGames()
	{
		super();
	
	}
	public OnlineGames(String gName, int gAmt) {
		super();
		this.gName = gName;
		this.gAmt = gAmt;
	}
	@Override
	public String toString() {
		return "OnlineGames [gName=" + gName + ", gAmt=" + gAmt + "]";
	}
	
	
}
