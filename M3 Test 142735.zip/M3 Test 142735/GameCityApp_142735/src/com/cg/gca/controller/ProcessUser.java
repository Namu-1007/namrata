package com.cg.gca.controller;

import java.io.IOException;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.cg.gca.dto.OnlineGames;
import com.cg.gca.dto.Users;
import com.cg.gca.exception.GameException;
import com.cg.gca.service.GameCityService;
import com.cg.gca.service.GameCityServiceImpl;


@WebServlet(urlPatterns={"/Process","/PlayNow"})
public class ProcessUser extends HttpServlet {
	private static final long serialVersionUID = 1L;
    
    public ProcessUser() 
    {
        super();
       
    }

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		doPost(request, response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		String url = request.getServletPath();
		String targetUrl = "";
		HttpSession sess = null;
		GameCityService gSer=new GameCityServiceImpl();
		switch(url)
		{
		case "/Process":
			String userName=request.getParameter("userName");
			String address=request.getParameter("address");
			int amount=Integer.parseInt(request.getParameter("amount"));
			
			sess = request.getSession(false);
			Users u=new Users();
			
			u.setUserName(userName);
			u.setAddress(address);
			u.setCardAmt(amount);
			sess=request.getSession(true);
			sess.setAttribute("amount", amount);
			
			try 
			{
				int id=gSer.addUserDetails(u);
				if(id == 1) 
				{
					List<OnlineGames> gList=gSer.getAllGames();
					sess.setAttribute("gList",gList);
					targetUrl="Play.jsp";
				}
				else
				{
					request.setAttribute("error", "Error while inserting data");
					targetUrl = "Error.jsp";
				}
			} 
			catch (GameException e) 
			{
				request.setAttribute("error", e.getMessage());
				targetUrl="Error.jsp";
			}
			
			break;
		
		case "/PlayNow":
			sess = request.getSession(false);
			Users u1=new Users();
			u1=(Users)sess.getAttribute("users");
			int cardBalance=u1.getCardAmt();
			int gameAmount=Integer.valueOf(request.getParameter("amount"));
			
			if(gameAmount <= cardBalance)
			{
				cardBalance = cardBalance - gameAmount;
				sess.setAttribute("cardBalance", cardBalance);
				targetUrl="Success.jsp";				
			}
			else
			{
				targetUrl="Topup.jsp";
			}
			break;
		}
			RequestDispatcher rd = request.getRequestDispatcher(targetUrl);
			rd.forward(request, response);
		
	}

}
