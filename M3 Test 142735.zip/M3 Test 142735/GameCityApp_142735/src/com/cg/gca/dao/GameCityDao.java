package com.cg.gca.dao;

import java.util.List;

import com.cg.gca.dto.OnlineGames;
import com.cg.gca.dto.Users;
import com.cg.gca.exception.GameException;

public interface GameCityDao 
{
	int addUserDetails(Users u) throws GameException;
	List<OnlineGames> getAllGames() throws GameException;
}
