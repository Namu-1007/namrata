package com.cg.gca.dao;

public interface QueryMapper
{
	String ADD_DETAILS="INSERT INTO Users VALUES(?,?,?,?)";
	String SELECT_SEQUENCE="SELECT seq_users.NEXTVAL FROM dual";
	String SELECT_ALL_GAMES="SELECT name,amount FROM onlinegames";
}
