package com.cg.gca.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import com.cg.gca.dto.OnlineGames;
import com.cg.gca.dto.Users;
import com.cg.gca.exception.GameException;
import com.cg.gca.util.DBUtil;

public class GameCityDaoImpl implements GameCityDao
{
	Connection conn=null;
	@Override
	public int addUserDetails(Users u) throws GameException 
	{
		int dataAdded=0;
		PreparedStatement pst;
		conn=DBUtil.getConnection();
		try 
		{
			pst=conn.prepareStatement(QueryMapper.ADD_DETAILS);
			pst.setInt(1, generateUserNo());
			pst.setString(2, u.getUserName());
			pst.setString(3, u.getAddress());
			pst.setInt(4, u.getCardAmt());
			dataAdded=pst.executeUpdate();
			
		} 
		catch (SQLException e) 
		{
			throw new GameException("Problem in inserting user details"+e.getMessage());
		}
		
		return dataAdded;
	}
	private int generateUserNo()throws GameException
	{
		int uNo=0;
		conn=DBUtil.getConnection();
		try
		{
			Statement st=conn.createStatement();
			ResultSet rs=st.executeQuery(QueryMapper.SELECT_SEQUENCE);
			rs.next();
			uNo=rs.getInt(1);
		}
		catch(SQLException e)
		{
			throw new GameException("Problem in generating user number"+e.getMessage());
		}
		return uNo;
	}
	@Override
	public List<OnlineGames> getAllGames() throws GameException 
	{
		List<OnlineGames> gList=new ArrayList<>();
		conn=DBUtil.getConnection();
		try 
		{
			Statement st=conn.createStatement();
			ResultSet rst=st.executeQuery(QueryMapper.SELECT_ALL_GAMES);
			while(rst.next())
			{
				OnlineGames og=new OnlineGames();
				og.setgName(rst.getString("name"));
				og.setgAmt(rst.getInt("amount"));
					
				gList.add(og);
				
			}
		} 
		catch (SQLException e) 
		{
			throw new GameException("Problem in fetching games"+e.getMessage());
		}
		
		return gList;
	}
}
